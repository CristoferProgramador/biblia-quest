import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Bíblia Quest | Conheça a Palavra', description: 'Aprenda a Bíblia de maneira interativa, um desafio de cada vez.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt-BR"><body>{children}</body></html>; }
